// index.js
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = process.env.PORT || 3000;

const callerData = {};

app.use(bodyParser.json());

app.post('/webhook', (req, res) => {
  res.json([
    {
      action: 'talk',
      text: 'Hello, this is E and L Insurance AI assistant. Please say Auto, Home, Business, or Agent to begin.'
    },
    {
      action: 'input',
      eventUrl: ['https://YOUR-RENDER-URL/webhook/input'],
      speech: { endOnSilence: 1, language: 'en-US' }
    }
  ]);
});

// More logic would go here...

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
